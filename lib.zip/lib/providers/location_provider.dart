import 'package:flutter/material.dart';
import 'package:eczane_vs/services/api_service.dart';

class LocationProvider extends ChangeNotifier {
  Map<String, String>? _location;
  List<Pharmacy> _pharmacies = [];

  Map<String, String>? get location => _location;
  List<Pharmacy> get pharmacies => _pharmacies;
  final ApiService _apiService = ApiService();

  Future<void> setLocation(Map<String, String> newLocation) async {
    _location = newLocation;
    notifyListeners();

    // Konum güncellenince nöbetçi eczaneleri çek
    await fetchPharmacies();
  }

  Future<void> fetchPharmacies() async {
    if (_location == null) return;

    _pharmacies = await _apiService.getDutyPharmacies(
      city: _location!['city'] ?? '',
      district: _location!['district'] ?? '',
    );
    notifyListeners();
  }
}
