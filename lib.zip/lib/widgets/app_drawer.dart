import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:eczane_vs/providers/location_provider.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AppDrawer extends StatelessWidget {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final user = _auth.currentUser;
    final locationProvider = Provider.of<LocationProvider>(context);
    final location = locationProvider.location;

    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            accountName: Text(user?.email ?? "Kullanıcı"),
            accountEmail: Text(
              "${location?['city'] ?? ''}, ${location?['district'] ?? ''}",
            ),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(Icons.person, size: 40, color: Colors.grey.shade800),
            ),
            decoration: BoxDecoration(color: Colors.red.shade800),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text('Ana Sayfa'),
            onTap: () {
              Navigator.pushReplacementNamed(context, '/home');
            },
          ),
          ListTile(
            leading: Icon(Icons.person),
            title: Text('Hesap Bilgilerim'),
            onTap: () {
              Navigator.pushNamed(context, '/profile');
            },
          ),
          ListTile(
            leading: Icon(Icons.location_on),
            title: Text('Konum Bilgilerim'),
            onTap: () {
              Navigator.pushNamed(context, '/location');
            },
          ),
          ListTile(
            leading: Icon(Icons.info),
            title: Text('Hakkında'),
            onTap: () {
              showAboutDialog(
                context: context,
                applicationName: "Nöbetçi Eczane",
                applicationVersion: "1.0.0",
                children: [Text("Nöbetçi eczane uygulaması")],
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.announcement),
            title: Text('Duyurular'),
            onTap: () {
              Navigator.pushNamed(context, '/announcements');
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.logout),
            title: Text('Çıkış Yap'),
            onTap: () async {
              await _auth.signOut();
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
          ListTile(
            leading: Icon(Icons.notifications),
            title: Text('Bildirimler'),
            onTap: () {
              Navigator.pushNamed(context, '/notifications');
            },
          ),
        ],
      ),
    );
  }
}
