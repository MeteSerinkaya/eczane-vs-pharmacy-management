import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> createUser({
    required String uid,
    required String email,
    required String city,
    required String district,
  }) async {
    final userRef = _firestore.collection('users').doc(uid);

    await userRef.set({
      'uid': uid,
      'email': email,
      'city': city,
      'district': district,
      'createdAt': FieldValue.serverTimestamp(),
      'lastLogin': FieldValue.serverTimestamp(),
    });
  }

  Future<void> updateLastLogin(String uid) async {
    final userRef = _firestore.collection('users').doc(uid);
    await userRef.update({'lastLogin': FieldValue.serverTimestamp()});
  }
}
