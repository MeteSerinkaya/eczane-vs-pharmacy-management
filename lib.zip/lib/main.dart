import 'package:eczane_vs/providers/theme_provider.dart';
import 'package:eczane_vs/screens/annoucement_screen.dart';
import 'package:eczane_vs/screens/notification_screen.dart';
import 'package:eczane_vs/screens/password_update_screen.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:eczane_vs/providers/location_provider.dart';
import 'package:eczane_vs/screens/home_screen.dart';
import 'package:eczane_vs/screens/location_update_screen.dart';
import 'package:eczane_vs/screens/login_screen.dart';
import 'package:eczane_vs/screens/register_screen.dart';
import 'package:eczane_vs/screens/profile_screen.dart';
import 'package:eczane_vs/services/location_service.dart';
import 'package:eczane_vs/firebase_options.dart';
import 'package:eczane_vs/services/notification_service.dart'; // NotificationService import edildi

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  String? token = await FirebaseMessaging.instance.getToken();
  print("FCM Token: $token");

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LocationProvider()),
        ChangeNotifierProvider(create: (_) => ThemeProvider()), // Yeni provider
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final NotificationService _notificationService = NotificationService();

  @override
  void initState() {
    super.initState();
    _notificationService.init(context);
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      themeMode: themeProvider.themeMode,
      initialRoute: '/',
      routes: {
        '/': (context) => const SplashScreen(),
        '/login': (context) => const LoginScreen(),
        '/register': (context) => const RegisterScreen(),
        '/profile': (context) => const ProfileScreen(),
        '/location': (context) => const LocationUpdateScreen(),
        '/password-update': (context) => const PasswordUpdateScreen(),
        '/announcements': (context) => AnnouncementsScreen(),
        '/notifications': (context) => NotificationScreen(),
      },
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final LocationService locationService = LocationService();
  String? _errorMessage;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadLocationAndNavigate();
    });
  }

  Future<void> _loadLocationAndNavigate() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      // Konum alma işlemi
      final location = await locationService.getCityandDistrict();

      // Provider ile konumu kaydet
      final locationProvider = Provider.of<LocationProvider>(
        context,
        listen: false,
      );
      await locationProvider.setLocation(location);

      User? user = FirebaseAuth.instance.currentUser;

      if (!mounted) return;

      if (user != null) {
        Navigator.of(
          context,
        ).pushReplacement(MaterialPageRoute(builder: (_) => HomePage()));
      } else {
        Navigator.of(context).pushReplacementNamed('/login');
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });

      if (!mounted) return;
      // SnackBar yerine hata mesajını ekranda gösteriyoruz (kullanıcı daha iyi görür)
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _isLoading
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('assets/images/eczane-seeklogo.png', width: 150),
                  const SizedBox(height: 20),
                  CircularProgressIndicator(color: Colors.red.shade800),
                  const SizedBox(height: 10),
                  const Text('Konum alınıyor, lütfen bekleyiniz...'),
                ],
              )
            : (_errorMessage != null
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.error, color: Colors.red, size: 60),
                        const SizedBox(height: 20),
                        Text(
                          'Konum alınırken hata oluştu:\n$_errorMessage',
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.red),
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: _loadLocationAndNavigate,
                          child: const Text('Tekrar Deneyin'),
                        ),
                      ],
                    )
                  : Container()), // Normal durumda UI zaten navigation yapıldığı için boş
      ),
    );
  }
}
