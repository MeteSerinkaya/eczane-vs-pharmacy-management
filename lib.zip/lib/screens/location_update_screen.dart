import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:eczane_vs/providers/location_provider.dart';

class LocationUpdateScreen extends StatefulWidget {
  const LocationUpdateScreen({super.key});

  @override
  State<LocationUpdateScreen> createState() => _LocationUpdateScreenState();
}

class _LocationUpdateScreenState extends State<LocationUpdateScreen> {
  late TextEditingController cityController;
  late TextEditingController districtController;

  @override
  void initState() {
    super.initState();
    final location = Provider.of<LocationProvider>(
      context,
      listen: false,
    ).location;
    cityController = TextEditingController(text: location?['city'] ?? '');
    districtController = TextEditingController(
      text: location?['district'] ?? '',
    );
  }

  @override
  void dispose() {
    cityController.dispose();
    districtController.dispose();
    super.dispose();
  }

  Future<void> _updateLocation() async {
    final newCity = cityController.text.trim();
    final newDistrict = districtController.text.trim();

    if (newCity.isEmpty || newDistrict.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Lütfen şehir ve ilçe bilgisini doldurun'),
        ),
      );
      return;
    }

    await Provider.of<LocationProvider>(
      context,
      listen: false,
    ).setLocation({'city': newCity, 'district': newDistrict});

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('Konum güncellendi')));

    Navigator.of(context).pop(); // Güncellemeden sonra önceki ekrana dön
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Konum Güncelleme")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: cityController,
              decoration: const InputDecoration(labelText: "Şehir"),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: districtController,
              decoration: const InputDecoration(labelText: "İlçe"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _updateLocation,
              child: const Text("Konumu Güncelle"),
            ),
          ],
        ),
      ),
    );
  }
}
