import 'package:eczane_vs/providers/theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:eczane_vs/providers/location_provider.dart';
import 'package:eczane_vs/widgets/app_drawer.dart';
import 'package:eczane_vs/services/auth_service.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});
  final AuthService _authService = AuthService();

  void _logout(BuildContext context) async {
    await _authService.signOut();
    Navigator.of(context).pushReplacementNamed('/');
  }

  @override
  Widget build(BuildContext context) {
    final locationProvider = Provider.of<LocationProvider>(context);
    final pharmacies = locationProvider.pharmacies;
    final location = locationProvider.location;
    final themeProvider = Provider.of<ThemeProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Nöbetçi Eczaneler - ${location?['city'] ?? ''}/${location?['district'] ?? ''}',
        ),
        actions: [
          IconButton(
            icon: Icon(
              themeProvider.themeMode == ThemeMode.dark
                  ? Icons.dark_mode
                  : Icons.light_mode,
            ),
            onPressed: () {
              themeProvider.toggleTheme();
            },
            tooltip: 'Tema Değiştir',
          ),
        ],
      ),
      drawer: AppDrawer(),
      body: pharmacies.isEmpty
          ? const Center(child: Text("Nöbetçi eczane bulunamadı."))
          : ListView.builder(
              itemCount: pharmacies.length,
              itemBuilder: (context, index) {
                final pharmacy = pharmacies[index];
                return ListTile(
                  title: Text(pharmacy.name),
                  subtitle: Text(pharmacy.address),
                  trailing: Text(pharmacy.phone),
                );
              },
            ),
    );
  }
}
